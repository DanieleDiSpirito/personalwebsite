<!DOCTYPE html>
<html lang="en">

<!-- Made by Daniele Di Spirito -->

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tic Tac Toe</title>
    <link rel="stylesheet" href="style.css"></link>
</head>
<body>
    <div id="title">TicTacToe</div>
    <button type="button" value="0" onclick="window.location.href = ''" style="visibility: hidden">Clicca qui per rigiocare</button>
    <?php for($i = 0; $i < 9; $i++): ?>
    <button value="1" name="<?=$i?>" style="font-size: 100px">&nbsp;</button>
    <?php endfor; ?>
    <div id="sconfitta" style="display: none" class="sconfitta">Hai perso!</div>
    <div id="patta" style="display: none" class="pareggio">Patta!</div>
    <script src="script.js"></script>
</body>
</html>
